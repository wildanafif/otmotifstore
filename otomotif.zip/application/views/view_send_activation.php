


	<div class="container">
		<div class="four">
      <div class="alert alert-success" role="alert">
        
  				<h2>Selamat !!!</h2>
  			 <p>Akun anda berhasil dibuat</p>
      </div>
				<p>Untuk Mengaktifkan akun silahkan klik link yang telah kami kirim ke email anda , periksa di kotak masuk jika tidak ditemukan cari di folder spam</p>
				
					
				
			</div>
</div>
</div

        <!---->
 <div class="header-top" style="margin-bottom:100px;margin-top:70px;">
        <div class="container">
        <div class="head-top">
      
                       <div class="alert alert-success" role="alert">
                         <center>
                              <h4>Anda telah berhasil memasang iklan <br>silahkan klik tombol di bawah untuk melihat iklan anda</h4><br><br>
                              <a href="<?php echo $url;?>"><button type="button" class="btn btn-success">Lihat Iklan</button></a>
                         </center>

                       </div>
                                           
                <div class="clearfix"> </div>
        </div>
        </div>
    </div>
   

</div>
</div>


<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config('appId')='1533208470324525';
$config('secret')='48af65a490ae801697b80a95a665820f';

?>
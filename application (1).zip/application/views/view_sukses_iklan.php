
        <!---->
 <div class="header-top" style="margin-bottom:100px;margin-top:70px;">
        <div class="container">
        <div class="head-top">
      
                       <div class="alert alert-success" role="alert">
                         <center>
                              <h4>Anda telah berhasil memasang iklan anda klik tombol di bawah untuk melihat iklan anda</h4><br><br>
                              <a href="<?php echo $url;?>"><button type="button" class="btn btn-success">Success</button></a>
                         </center>

                       </div>
                                           
                <div class="clearfix"> </div>
        </div>
        </div>
    </div>
   

<div class= "modal fade" id= "myModaldaftar" tabindex= "-1" role= "dialog" aria-labelledby= "myModalLabel" aria-hidden= "true" >
   <div class= "modal-dialog" >
    <div class= "modal-content" style="width:100%">

<div class="panel panel-default">
            <div class="panel-heading">
              <center><h3 class="panel-title">Pilih<small> Provinsi</small>  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"> &times; </span></button></h3></center>
            </div>
            <div class="panel-body">
            
             <div class="col-md-4"><a href="" onClick="addProv('jawa timur')"  data-dismiss="modal" disabled style=";"><i><b>jawa timur</b></i> </a></div>
             <div class="col-md-4"><a href="" onClick="addProv('jawa barat')"  data-dismiss="modal" disabled style=";"><i><b>jawa barat</b></i> </a></div>
               </div>
          </div>
         </div>
        </div> 
      </div>





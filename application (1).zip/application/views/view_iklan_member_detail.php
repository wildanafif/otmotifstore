<div class="top-header">        
        <div class="container">
        <div class="top-head" >            
                <div class="search"  >
            <div class="top-heade">
                <form name="prov">
                        <input type="text" name="isi" id="txtSearch" data-toggle= "modal" data-target= "#myModaldaftar" placeholder="Kategori" readonly onblur="if (this.value == '') {this.value = 'pilih provinsi';}" >
            </div>
                </div>
                <div class="search"  >
            <div class="top-heade">
                <form name="prov">
                        <input type="text" name="isi" id="txtSearch" data-toggle= "modal" data-target= "#myModaldaftar" placeholder="Pilih Lokasi" readonly onblur="if (this.value == '') {this.value = 'Pilih Lokasi';}" >
            </div>
                </div>
            <div class="search">
                <div class="top-heade"><input type="text" value="search about something ?" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'search about something ?';}" >
                        <button id='search-button' type='submit' style="margin-top:-2px;"><span>Search</span></button></div>    
</div>                    
                    </form>
                <div class="clearfix"> </div>
        </div>
        </div>
    </div>
        <!---->

</div>
<div class= "modal fade" id= "myModaldaftar" tabindex= "-1" role= "dialog" aria-labelledby= "myModalLabel" aria-hidden= "true" >
   <div class= "modal-dialog" >
    <div class= "modal-content" style="width:100%">

<div class="panel panel-default">
            <div class="panel-heading">
              <center><h3 class="panel-title">Pilih<small> Provinsi</small>  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"> &times; </span></button></h3></center>
            </div>
            <div class="panel-body">
            
             <div class="col-md-4"><a href="" onClick="addProv('jawa timur')"  data-dismiss="modal" disabled style=";"><i><b>jawa timur</b></i> </a></div>
             <div class="col-md-4"><a href="" onClick="addProv('jawa barat')"  data-dismiss="modal" disabled style=";"><i><b>jawa barat</b></i> </a></div>
               </div>
          </div>
         </div>
        </div> 
      </div>

<div style="margin-bottom:20px;" ></div>

         
  <div class="container">
   
    <div class="well well-sm">
      
      <strong style="font-size:20px;">Garasi <?php echo $user['nama']; ?></strong>
        <strong class="hilang"  style="margin-left:40%; ">Category Title</strong>
        <div class="btn-group hilang">
            <a href="#" id="list" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-th-list">
            </span>List</a> <a href="#" id="grid" class="btn btn-default btn-sm"><span
                class="glyphicon glyphicon-th"></span>Grid</a>
        </div>

        
       
   
    </div>
    
      
    <div id="products" class="row list-group">
        <?php
                               if(isset($produk)){
                                foreach($produk as $data_produk){ ?>
     
       
        <div class="item  col-xs-4 col-lg-4 list-group-item">
            <div class="thumbnail">
                <img class="group list-group-image" src="<?=base_url()?><?php echo $data_produk['temp_foto']; ?>" alt="" />
                <div class="caption">
                    <h5 class="group inner list-group-item-heading">
                       <a href="<?php echo site_url()?>iklan/view/<?php echo $data_produk['id_iklan']; ?>/<?php echo $data_produk['waktu']; ?>"><?php echo $data_produk['judul_iklan']; ?></a> <p class="" style="float:; margin-top:10px; margin-bottom:10px;" >
                               <?php 
                               $format_indonesia20 = number_format ($data_produk['harga'], 2, ',', '.');
                               echo "Rp. ".$format_indonesia20; ?></p></h5>
                    <p class="group inner list-group-item-text">
                       <?php echo $data_produk['kategori']; ?> >> <?php echo $data_produk['sub_kategori']; ?></p>
             
                            <p class="" style="margin-bottom:5px;" >
                              <?php echo $data_produk['daerah']; ?> -  <?php echo $data_produk['provinsi']; ?> </p>
                        
                </div>
            </div>
        </div>

          <?php


                                    // $no++;
                                    // $this->table->add_row(
                                    // $no,
                                    // $data_produk['kategori'],
                                    // $data_produk['judul_iklan'],
                                    // $data_produk['provinsi']
                                    // ); 
                                }
                            }
                        ?>
                         
    </div>
     <div  ><center><?php echo $halaman;?></center> </div>


</div>        
      
        

